<!-- START -->
<section>
	<div class="ad-menu-lhs mshow">
		<div class="ad-menu">
			<ul>
				<li class="ic-db"> <a href="profile.php" class="mact">Dashboard</a>
				</li>
				
				
				<li class="ic-user"> <a href="#" class="">Users</a>
					<div>
						<ol>
							
							
							<li> <a href="admin-all-users.php">All Users</a>
							</li>
							
							<li> <a href="admin-add-new-user.php">Add new User</a>
							</li>
						</ol>
					</div>
				</li>
				<li class="ic-cat"> <a href="#" class="">Product Category</a>
					<div>
						<ol>
							<li> <a href="admin-all-product-category.php">All Category</a>
							</li>
							<li> <a href="admin-add-new-product-category.php">Add new Category</a>
							</li>
							<li> <a href="admin-all-product-sub-category.php">All Sub Category</a>
							</li>
							<li> <a href="admin-add-new-product-sub-category.php">Add new Sub Category</a>
							</li>
						</ol>
					</div>
				</li>
				
				<li class="ic-prod"> <a href="#" class="">Products</a>
					<div>
						<ol>
							<li> <a href="admin-all-products.php">All Products</a>
							</li>
							<li> <a href="admin-add-new-product.php">Add new Product</a>
							</li>
						</ol>
					</div>
				</li>
				
				
				
				<li class="ic-enq"> <a href="#" class="">Enquiry & Get Quote</a>
					<div>
						<ol>
							<li> <a href="admin-all-enquiry.html">All Enquiry</a>
							</li>
							<li> <a href="admin-saved-enquiry.html">Saved Enquiry</a>
							</li>
						</ol>
					</div>
				</li>
				<li class="ic-rev"> <a href="#" class="">Reviews</a>
					<div>
						<ol>
							<li> <a href="admin-all-reviews.html">All Reviews</a>
							</li>
							<li> <a href="admin-saved-reviews.html">Saved Reviews</a>
							</li>
						</ol>
					</div>
				</li>
				
				<li class="ic-noti"> <a href="#" class="">Send Notifications</a>
					<div>
						<ol>
							<li> <a href="admin-notification-all.html">All Notifications</a>
							</li>
							<li> <a href="admin-create-notification.html">Create New Notifications</a>
							</li>
						</ol>
					</div>
				</li>
			
				<li class="ic-hom"> <a href="#" class="">Home Page</a>
					<div>
						<ol>
							<li> <a href="admin-home-top-section.html">Top Section</a>
							</li>
							<li> <a href="admin-home-category.html">Choose Category</a>
							</li>
							<li> <a href="admin-trending-category.html">Choose Trending Category</a>
							</li>
							<li> <a href="admin-home-popular-business.html">Popular Business</a>
							</li>
							<li> <a href="admin-home-top-services.html">Top Services</a>
							</li>
							<li> <a href="admin-home-feature-events.html">Feature Events</a>
							</li>
							<li> <a href="home-page-template.html">Home page template</a>
							</li>
						</ol>
					</div>
				</li>
			
				<li class="ic-sub"> <a href="#" class="">Footer</a>
					<div>
						<ol>
							<li> <a href="admin-footer.html">Footer CMS</a>
							</li>
							<li> <a href="admin-footer-popular-tags.html">Footer popular tags</a>
							</li>
						</ol>
					</div>
				</li>
				<li class="ic-slid"> <a href="#" class="">Slider Images</a>
					<div>
						<ol>
							<li> <a href="admin-slider-all.php">All Slider Images</a>
							</li>
							<li> <a href="admin-slider-create.php">Add New Slider</a>
							</li>
						</ol>
					</div>
				</li>
				
				</li>
				<li class="ic-lgo"> <a href="logout.php">Log out</a>
				</li>
			</ul>
		</div>
	</div>
</section>